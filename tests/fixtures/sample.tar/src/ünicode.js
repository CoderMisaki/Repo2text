const pesan = "halo 🌍";
