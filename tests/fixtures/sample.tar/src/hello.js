console.log("hello-world");
function x() {
  return 1;
}
